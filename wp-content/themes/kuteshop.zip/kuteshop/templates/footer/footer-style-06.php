<?php
/**
 * Name:  Footer style 06
 **/
?>
<footer class="footer style6">
    <div class="container">
		<?php the_content(); ?>
    </div>
</footer>
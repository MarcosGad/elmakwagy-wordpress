<?php
/**
 * Name:  Footer style 02
 **/
?>
<footer class="footer style2">
    <div class="container">
		<?php the_content(); ?>
    </div>
</footer>
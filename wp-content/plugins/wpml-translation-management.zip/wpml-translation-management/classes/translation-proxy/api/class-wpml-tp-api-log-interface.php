<?php

interface WPML_TP_API_Log_Interface {

	public function log( $action, $data = array() );

}